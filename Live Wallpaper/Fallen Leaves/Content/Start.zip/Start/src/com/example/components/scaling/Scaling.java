package com.example.components.scaling;

public class Scaling implements Scalable{
    
    private double backgroundWidth;
    private double backgroundHeight;

    
    public Scaling(double backgroundWidth, double backgroundHeight){
        this.backgroundHeight = backgroundHeight;
        this.backgroundWidth = backgroundWidth;
    }

    public double scaleTheWidth(int percent) {
         return backgroundWidth/100 * percent;
    }

    public double scaleTheHeight(int percent) {
         return backgroundHeight/100 * percent;
    }
    
    
    
}
