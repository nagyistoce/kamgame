package com.example.Enum;

public enum TypeWind {
      SOUTH(80,100), WEST(0,45), EAST(135,180) , SOUTH_EAST(100,135), SOUTH_NEST(45,80);

      private int lowLimitAngle;
      private int topLimitAngle;

      private TypeWind(int lowLimitAngle , int upperLimitAngle ){
           this.lowLimitAngle = lowLimitAngle;
           this.topLimitAngle = upperLimitAngle;
      }

      public int getLowLimitAngle(){
          return lowLimitAngle;
      }

      public int getTopLimitAngle(){
          return topLimitAngle;
      }
}
