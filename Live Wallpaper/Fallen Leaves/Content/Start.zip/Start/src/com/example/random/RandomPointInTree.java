package com.example.random;

import com.example.components.PointInTree;
import com.example.components.Tree;



public class RandomPointInTree extends MyRandom {
    private Tree tree;
    private int xPoint;
    private int yPoint;

    public RandomPointInTree(Tree tree) {
        this.tree = tree;
    }

    public PointInTree generatePoint(){
       int padding = tree.getWidth()/8;
       xPoint = random.nextInt(tree.getWidth() - 2*padding) + tree.getCurrentPositionX() + padding;
       yPoint = random.nextInt(tree.getHeight() - tree.getHeightTreeBody() - 2*padding) + tree.getCurrentPositionY() + padding;
       return  new PointInTree(xPoint, yPoint);
    }


}
