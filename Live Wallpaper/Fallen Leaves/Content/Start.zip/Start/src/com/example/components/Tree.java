package com.example.components;

import android.content.res.Resources;
import android.graphics.Canvas;
import com.example.random.RandomPointInTree;


import java.util.ArrayList;
import java.util.HashSet;

public class Tree extends AbstractComponent{

    private HashSet<PointInTree> arrayPointInTrees = new HashSet<PointInTree>();
    private RandomPointInTree randomPointInTree = new RandomPointInTree(this);
    private double heightTreeBody;


    public Tree(Resources resources, int currentPositionX,int currentPositionY, int image){
        super(resources, currentPositionX, currentPositionY, 5, 5, image);
        heightTreeBody = height - height/4;
    }

    public Tree(Resources resources, double width, double height, double currentPositionX, double currentPositionY, int image){
        super(resources, (int)width, (int)height, (int)currentPositionX, (int)currentPositionY, image);
        heightTreeBody = height - height/2;
    }


    public PointInTree[] getArrayPointInTree(){
        generetePoints(3);
        return (PointInTree[])arrayPointInTrees.toArray(new PointInTree[]{});
    }

    public void generetePoints(int numberPoints){
        arrayPointInTrees.clear();
        while(arrayPointInTrees.size() != numberPoints){
            arrayPointInTrees.add(randomPointInTree.generatePoint());
        }
    }

    @Override
    protected void setIsRotate() {
        this.isRotate = false;
    }

    public int getHeightTreeBody() {
        return (int)heightTreeBody;
    }
}
