package com.example.main;

import com.example.Enum.Image;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.service.wallpaper.WallpaperService;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import com.example.components.AbstractComponent;
import com.example.animation.AnimatedLeaf;
import com.example.components.Background;
import com.example.components.Tree;
import com.example.components.positioning.Positioning;
import com.example.components.scaling.Scaling;



import java.util.ArrayList;
import java.util.Scanner;

public class TreeWallpaper extends WallpaperService {
    @Override
    public Engine onCreateEngine() {
        return new TreeEngine();  //To change body of implemented methods use File | Settings | File Templates.
    }


    private class TreeEngine extends Engine{

        private Background background;
        private Tree tree;
        private int width;
        private int height;
        private int heightLand;
        private Scaling scaling;
        private AnimatedLeaf animatedLeaf;
        private Positioning positioning;
        private Resources resources;
        private ArrayList<AbstractComponent> allComponent;
        private AnimatedLeaf.StatusThread statusThread;

        private Bitmap image;


        public TreeEngine(){
            this.resources = getApplicationContext().getResources();
            allComponent = new ArrayList<AbstractComponent>();
            image = BitmapFactory.decodeResource(resources, Image.BACKGROUND.getIdImage());
        }

        @Override
        public void onTouchEvent(MotionEvent event) {
            super.onTouchEvent(event);
            if(allComponent.size() == 0)
                    addBackgroundElement();
            initAnimatedLeaf();
            initStatusAnimatedThread();
            if(!statusThread.isWaitAppendElement()){
                if(!statusThread.isRunThread())
                    animatedLeaf.start(); 
            }
            else{
                statusThread.resumeAppendElement();
                onTouchEvent(event);
            }
            
        }

        @Override
        public void onOffsetsChanged(float xOffset, float yOffset, float xOffsetStep, float yOffsetStep, int xPixelOffset, int yPixelOffset) {
            super.onOffsetsChanged(xOffset, yOffset, xOffsetStep, yOffsetStep, xPixelOffset, yPixelOffset);    //To change body of overridden methods use File | Settings | File Templates.

        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);    //To change body of overridden methods use File | Settings | File Templates.
            this.width = width;
            this.height = height;
            this.heightLand = height/9;
            this.scaling = new Scaling(width, height);
            this.background = new Background(resources, width, height, 0, 0, Image.BACKGROUND.getIdImage());
            this.positioning = new Positioning(width, height);
            
            
            initTree();
            drawComponent();
        }



        private void drawComponent(){
            Canvas canvas = null;
            SurfaceHolder holder = getSurfaceHolder();
            try{
                canvas = getSurfaceHolder().lockCanvas();
                if(canvas != null){
                    this.background.draw(canvas);
                    this.tree.draw(canvas);
                }
            }
            finally {
                if (canvas != null)
                    holder.unlockCanvasAndPost(canvas);
            }
        }

        private void addBackgroundElement(){
            allComponent.add(this.background);
            allComponent.add(this.tree);
        }
        
        private void initAnimatedLeaf(){
             if(animatedLeaf == null)
                    animatedLeaf = new AnimatedLeaf(resources,getSurfaceHolder(),allComponent, width, height);         
        }
        
        private void initStatusAnimatedThread(){
            if(statusThread == null)
                 statusThread = animatedLeaf.getStatusThread();
        }

        private void initTree(){
            double treeWidth = this.scaling.scaleTheWidth(50);
            double treeHeight = this.scaling.scaleTheHeight(30);
            int xPosition = positioning.positionXPercent(34);
            int yPosition = positioning.positionYPercent(64);
            this.tree = new Tree(resources, treeWidth, treeHeight, xPosition, yPosition,Image.TREE.getIdImage());
        }
    }

}
