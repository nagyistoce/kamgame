package com.example.components;

import com.example.random.MyRandom;
import com.example.Enum.Side;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;


import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;
import java.util.ResourceBundle;

public class Leaf extends AbstractComponent{
    private double speedX;
    private double speedY;
    private MyRandom random;

    public Leaf(Resources resources, int width, int height, int currentPositionX, int currentPositionY, int image ){
        super(resources, width, height, currentPositionX, currentPositionY, image);
        random = MyRandom.getInstance();
        this.speedY = random.randomSpeed();
        this.speedX = random.randomSpeed();
    }

    public void repaint(){
        currentPositionY += speedY;
        currentPositionX -= speedX;
    }

    @Override
    protected void setIsRotate() {
        this.isRotate = true;
    }

}
