package com.example.Enum;

import com.example.R;



public enum Image {

    TREE(R.drawable.tree), LEAR(R.drawable.leaf), BACKGROUND(R.drawable.background);

    private int idImage;
    private Image(int idImage){
        this.idImage = idImage;
    }

    public int getIdImage(){
        return idImage;
    }
}
