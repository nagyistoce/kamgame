package com.example.Enum;

public enum Side {
    Left, Right
}
