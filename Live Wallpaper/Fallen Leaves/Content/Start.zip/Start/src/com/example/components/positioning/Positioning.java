package com.example.components.positioning;

public class Positioning implements Positable{

    private int width;
    private int height;

    public Positioning(int width, int height) {
        this.width = width;
        this.height = height;
    }
    
    
    public int positionXPercent(int percent) {
        return width / 100 * percent;
    }

    public int positionYPercent(int percent) {
        return height/100 * percent;
    }

    public int positionXPixels(int pixels) {
        return width - pixels;
    }

    public int positionYPixels(int pixels) {
        return height - pixels;
    }
    
}
