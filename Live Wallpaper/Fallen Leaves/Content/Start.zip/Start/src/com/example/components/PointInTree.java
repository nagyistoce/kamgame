package com.example.components;
public class PointInTree {
    private int xPosition,
                yPosition;

    public PointInTree(int xPosition, int yPosition) {
        this.xPosition = xPosition;
        this.yPosition = yPosition;
    }

    public int getxPosition() {
        return xPosition;
    }

    public int getyPosition() {
        return yPosition;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PointInTree that = (PointInTree) o;

        if (xPosition != that.xPosition) return false;
        if (yPosition != that.yPosition) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = xPosition;
        result = 31 * result + yPosition;
        return result;
    }
}
