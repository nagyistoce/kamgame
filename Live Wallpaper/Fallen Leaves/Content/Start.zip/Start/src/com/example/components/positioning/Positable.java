package com.example.components.positioning;

public interface Positable {
    public int positionXPercent(int percent);
    public int positionYPercent(int percent);
    public int positionXPixels(int pixels);
    public int positionYPixels(int pixels);
}
