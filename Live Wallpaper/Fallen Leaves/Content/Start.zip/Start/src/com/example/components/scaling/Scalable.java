
package com.example.components.scaling;


public interface Scalable {
    public double scaleTheWidth(int percent);
    public double scaleTheHeight(int percent);
}
