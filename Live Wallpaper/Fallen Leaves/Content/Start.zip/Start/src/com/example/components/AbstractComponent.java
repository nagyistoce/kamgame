package com.example.components;

import com.example.random.MyRandom;
import android.content.res.Resources;
import android.graphics.*;

public abstract class AbstractComponent {

    protected double currentPositionX,
                  currentPositionY;

    protected int width,
                  height;

    protected Resources resources;

    protected Bitmap image;
    protected int drawableImage;

    protected boolean isRotate;
    private int rotateAngle;

    public AbstractComponent(Resources resources, int width, int height, int currentPositionX, int currentPositionY ,int image){
        setParameters(resources, width, height, currentPositionX, currentPositionY,image);
    }

    public int getCurrentPositionX(){
        return (int)currentPositionX;
    }

    public int getCurrentPositionY(){
        return (int)currentPositionY;
    }

    public int getHeight() {
        return height;
    }

    public int getWidth() {
        return width;
    }

    public void draw(Canvas canvas){
        if(image == null){
            this.image = BitmapFactory.decodeResource(resources, drawableImage);
            this.image = Bitmap.createScaledBitmap(image , width , height, false);
        }
        if(isRotate){
            Matrix matrix = rotate(rotateAngle);
            canvas.drawBitmap(image, matrix, null);
        }
        else{
            canvas.drawBitmap(image , (int)currentPositionX ,(int)currentPositionY , null);
        }
    }

    private Matrix rotate(int angle){
        Matrix matrix = new Matrix();
        matrix.setTranslate((int)currentPositionX, (int)currentPositionY);
        matrix.preRotate(rotateAngle, width/2, height/2);
        return matrix;
    }
    private void setParameters(Resources resources, int width, int height,int currentPositionX,int currentPositionY , int image ){
        this.currentPositionX = currentPositionX;
        this.currentPositionY = currentPositionY;
        this.width = width;
        this.height = height;
        this.resources = resources;
        this.drawableImage = image;
        setIsRotate();
        rotateAngle = MyRandom.getInstance().getRotateAngle();
    }
    protected abstract void setIsRotate();
}
