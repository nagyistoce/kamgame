package com.example.components;


import android.content.res.Resources;
import android.graphics.Canvas;

public class Background extends AbstractComponent{

    public Background(Resources resources, int currentPositionX,int currentPositionY, int image){
        super(resources, currentPositionX, currentPositionY, 5, 5, image);
    }

    public Background(Resources resources, int width, int height, int currentPositionX, int currentPositionY, int image){
        super(resources, width, height, currentPositionX, currentPositionY, image);
    }

    @Override
    protected void setIsRotate() {
        this.isRotate = false;
    }


}
