package com.example.random;



import com.example.Enum.Side;
import java.util.Random;

public class MyRandom {
    protected Random random;

    protected MyRandom(){
        random = new Random(System.currentTimeMillis());
    }

    public static MyRandom getInstance(){
        return new MyRandom();
    }

    /*Возвращаем в процентах от всего размера экрана*/
    public int getSizeLeaf(){
        return random.nextInt(3) + 3;
    }

    public Side getRandomSide(){
        int flag = random.nextInt(2) + 1;
        if(flag == 1){
            return Side.Right;
        }
        else{
            return Side.Left;
        }
    }

    public double randomSpeed(){
        double result = random.nextDouble() % 1;
        if(result > 0.5)
            return result;
        else
            return randomSpeed();
    }

    public int getRotateAngle(){
        return random.nextInt(180);
    }

}
