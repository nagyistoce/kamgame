package com.example.animation;

import com.example.Enum.TypeWind;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.view.SurfaceHolder;
import com.example.Enum.Image;
import com.example.components.AbstractComponent;
import com.example.components.Leaf;
import com.example.components.PointInTree;
import com.example.components.Tree;
import com.example.components.scaling.Scaling;

import com.example.random.MyRandom;


import java.util.ArrayList;
import java.util.Random;

public class AnimatedLeaf extends Thread {

    private Scaling scaling;
    private ArrayList<Leaf> allLeaf;
    private SurfaceHolder holder;
    private ArrayList<AbstractComponent> allComponents;
    private Resources resources;
    private int numberBoom;
    private PointInTree[] pointInTree;
    private Tree tree;
    private StatusThread statusThread; 
    private MyRandom myRandom;
    private int numberIteration;
    private int interval;
    private double backgroundWidth;
    private double backgroundHeight;
    
    
    public AnimatedLeaf(Resources resources, SurfaceHolder holder, ArrayList<AbstractComponent> allComponent , double backgroundWidth , double backgroundHeight){       
        this.allComponents = allComponent;
        this.holder = holder;
        this.resources = resources;
        this.backgroundHeight = backgroundHeight;
        this.backgroundWidth = backgroundWidth;
        init();
    }

    @Override
    public void run(){
        statusThread.startThread();
        onDraw();
    }
 
    public StatusThread getStatusThread(){
        return statusThread;
    }
    
    private void onDraw(){
        while(statusThread.isRunThread() && !statusThread.isWaitThread()){
            Canvas canvas = null;
            try{
                canvas = holder.lockCanvas();
                if(canvas != null){
                    drawAllComponent(canvas);
                    if(!statusThread.isWaitAppendElement() && numberIteration == interval){
                        numberIteration = 0;
                        numberBoom++;
                        addLeafOnEachPoint();
                        pointInTree = tree.getArrayPointInTree();
                    }
                    paintAllLeaf(canvas);
                    numberIteration++;
                    if(numberBoom >= 2){
                        statusThread.waitAppendElement();
                        numberBoom = 0;
                    }
                }
            }
            finally {
                if (canvas != null)
                    holder.unlockCanvasAndPost(canvas);
            }
        }
    }
      
    
    /*Рисуем все листья на экране*/
    private void paintAllLeaf(Canvas canvas){
        for(int i = 0; i < allLeaf.size(); i++){
           Leaf leaf = allLeaf.get(i);
           if(leaf.getCurrentPositionX() > 0 && leaf.getCurrentPositionY() > 0){
              leaf.draw(canvas);
              leaf.repaint();
           }
           else{
              allLeaf.remove(i);
           }                
        } 
    }
    
    /*Добавляем листки на сгенерированые точки*/
    private void addLeafOnEachPoint(){
        for(int i = 0 ; i < pointInTree.length ; i++){
           PointInTree point = pointInTree[i];
           int percent = myRandom.getSizeLeaf();
           int sizeLeaf = (int)scaling.scaleTheWidth(percent);
           addLeaf(new Leaf(resources, sizeLeaf, sizeLeaf, point.getxPosition(),point.getyPosition(), Image.LEAR.getIdImage()));
        }
    }
    
    private void addLeaf(Leaf leaf){
         allLeaf.add(leaf);
    }
    
    /*Рисуем дерево и задний фон*/
    private void drawAllComponent(Canvas canvas){
        for(AbstractComponent abstractComponent: allComponents){
            abstractComponent.draw(canvas);
        }
    }

    private void init(){
        tree = (Tree)allComponents.get(1);
        pointInTree = tree.getArrayPointInTree();
        this.numberBoom = 0;
        this.interval = 30;
        statusThread = new StatusThread();
        allLeaf = new ArrayList<Leaf>();
        myRandom = MyRandom.getInstance();
        scaling = new Scaling(this.backgroundWidth, this.backgroundHeight);
    }
    
    public class StatusThread{
        private boolean run;
        private boolean wait;
        private boolean waitAppendElement;
        
        public void startThread(){
            this.run = true;
        }
        
        public void waitThread(){
            this.wait = true;
        }
        
        public void waitAppendElement(){
            this.waitAppendElement = true; 
        }
        
        public boolean isRunThread(){
            return run;
        }
        
        public boolean isWaitThread(){
            return wait;
        }
        
        public boolean isWaitAppendElement(){
            return waitAppendElement;
        } 
        
        public void resumeAppendElement(){
            this.waitAppendElement = false;
            numberIteration = 0;
        }
    }
}
